you wil have to execute the main.py
and then enjoy the game !